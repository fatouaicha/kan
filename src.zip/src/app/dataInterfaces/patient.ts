import {sexeEnum} from "./sexe";
import {Adresse} from "./adress";

export interface PatientInterface {
  prenom: string;
  nom: string;
  sexe: sexeEnum;
  numeroSecuriteSociale: string;
  adresse: {
    ville: string;
    codePostal: number;
    rue: string;
    numero: string;
    etage: string;
    lat: number;
    lng: number;
  };
}
