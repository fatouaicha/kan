import {InfirmierInterface} from "./nurse";
import {PatientInterface} from "./patient";


export interface CabinetInterface {
  infirmiers: InfirmierInterface[];
  patientsNonAffectés: PatientInterface  [];
}
