// c'est un service qui permet de récupérer des données du serveur
import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';
import {NgForm} from '@angular/forms';
import {CabinetInterface} from './dataInterfaces/cabinet';
import {Adresse} from './dataInterfaces/adress';
import {InfirmierInterface} from './dataInterfaces/nurse';
import {PatientInterface} from './dataInterfaces/patient';
import {sexeEnum} from './dataInterfaces/sexe';
import 'rxjs/add/operator/toPromise';



@Injectable()
export class CabinetMedicalService {
  constructor(private http: Http) { }
  getData( url: string ): Promise<CabinetInterface> {
    return this.http.get(url).toPromise().then( (res: Response) => {
      console.log(url, '=>' , res);
      const cabinet: CabinetInterface = {
        infirmiers          : [],
        patientsNonAffectés : []
      };
      const text = res.text(); // on met le texte récuperer dans une constante text
      const parser = new DOMParser();
      const doc = parser.parseFromString(text, 'text/xml');
      const patientsXML     = doc.querySelectorAll('patient');
      const infirmiersXML   = doc.querySelectorAll('infirmier');

      // Les infirmiers
      for (const infirmierXML of infirmiersXML){
        const infirmier: InfirmierInterface = {
          id      : infirmierXML.getAttribute('id'),
          nom     : infirmierXML.querySelector('nom').textContent,
          prenom  : infirmierXML.querySelector('prénom').textContent,
          photo   : infirmierXML.querySelector('photo').textContent,
          patients: []
        };
        cabinet.infirmiers.push( infirmier );
      }


      // Les patients
      const patients: PatientInterface [] = [];
      for (const patientXML of patientsXML) {
        let etage = '', numero = '';    // on crée et initialise etage et numero à vide
        if (patientXML.querySelector('étage')) {   // si le patient a un étage
          etage = patientXML.querySelector('étage').textContent; // on met la valeur de l'étage dans la variable etage qu'on a crée
        }
        if (patientXML.querySelector('adresse numero')) {
          numero = patientXML.querySelector('adresse numero').textContent;
        }

        const patient: PatientInterface = {
          prenom     : patientXML.querySelector('prénom').textContent,
          nom  : patientXML.querySelector('nom').textContent,
          sexe  : patientXML.querySelector('sexe').textContent === 'M' ? sexeEnum.M : sexeEnum.F,
          numeroSecuriteSociale : patientXML.querySelector('numéro').textContent,
          adresse : {
            ville       : patientXML.querySelector('ville').textContent,
            codePostal  : patientXML.querySelector('codePostal').textContent,
            rue         : patientXML.querySelector('rue').textContent,
            numero      : numero,
            etage       : etage,
            lat         : undefined,
            lng         : undefined
          }
        };
        patients.push(patient);


      }



      return cabinet;
    });
  }

  AjouterPatient(f: NgForm): Promise<PatientInterface> {
    const controls = f.form.controls;
    const body     = {};
    for (const v in controls) {
      body[v] = controls[v].value;
    }
    return this.http.post( './addPatient', body ).toPromise().then( () => {
      const patient: PatientInterface = {
        prenom      : body['patientName'],
        nom         : body['patientForname'],
        sexe        : body['patientSex'] === 'M' ? sexeEnum.M : sexeEnum.F,
        numeroSecuriteSociale : body['patientNumber'],
        adresse : {
          ville       : body['patientCity'],
          codePostal  : body['patientPostalCode'],
          rue         : body['patientStreet'],
          numero      : body['patientStreetNumber'],
          etage       : body['patientFloor'],
          lat         : undefined,
          lng         : undefined
        }
      };
      return patient;
    });
  }

}


