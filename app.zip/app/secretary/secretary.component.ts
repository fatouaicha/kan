import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {CabinetMedicalService} from '../cabinet-medical.service';
import {CabinetInterface} from '../dataInterfaces/cabinet';
import {InfirmierInterface} from '../dataInterfaces/nurse';
import {PatientInterface} from '../dataInterfaces/patient';
import {NgForm} from "@angular/forms";


@Component({
  selector: 'app-secretary',
  templateUrl: './secretary.component.html',
  styleUrls: ['./secretary.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SecretaryComponent implements OnInit {
  initDone: boolean ;
  infirmiers: InfirmierInterface [] = [];
  patientsNonAffectés: PatientInterface   [] = [];


  constructor		(public cs: CabinetMedicalService) {
  }
  ngOnInit() {    // initialise le component

    this.cs.getData( "/data/cabinetInfirmier.xml" ).then( (cabinet: CabinetInterface) => {
      console.log( "\t=> cabinetJS:", cabinet );
      this.initDone = true;
      this.infirmiers = cabinet.infirmiers;
      this.patientsNonAffectés = cabinet.patientsNonAffectés;
    }, (err) => {console.error('Erreur lors du chargement du cabinet', '/data/cabinetInfirmier.xml', '\n', err); } );
  }
  getInfirmiers() {
    return this.infirmiers;
  }
  getPatients() {
    return this.patientsNonAffectés;
  }



  AjouterPatient (f: NgForm) {
    this.cs.AjouterPatient(f).then( (patient: PatientInterface) => {

      this.patientsNonAffectés.push(patient);
      console.log('Patient Ajouté avec succés');
    });
  }


}
