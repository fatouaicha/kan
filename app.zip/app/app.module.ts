import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { CabinetMedicalService } from './cabinet-medical.service';
import { SecretaryComponent } from './secretary/secretary.component';
import { DragDropModule } from './secretary/DragDrop/DragDropModule';



@NgModule({
  declarations: [
    AppComponent,
    SecretaryComponent,


  ],
  imports: [
    BrowserModule, HttpModule, FormsModule, DragDropModule,
  ],
  providers: [CabinetMedicalService],
  bootstrap: [AppComponent]
})
export class AppModule { }
